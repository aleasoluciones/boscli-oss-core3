import bostypes
import boscliutils
import boscli

import ConfigParser
import glob
import os.path
import datetime


class CapscliPlugin():
    Servers = None
    DataDir = '/var/lib/capscli/'
    
    def __init__(self):
        self.loadconf()

    def loadconf(self):
        boscliutils.Log.info("Loading configuration")        
        CapscliPlugin.Servers = open("/etc/capscli/servers", "r").read().splitlines()    
        try:
            # create capsdir if not exists            
            os.makedirs(CapscliPlugin.DataDir)
        except OSError:
            # already exists... 
            pass

        

boscliutils.Log.info("Initialization")        
CapscliPlugin()


class CapscliServer(bostypes.BiferShellType):
    def __init__(self): 
        bostypes.BiferShellType.__init__(self,
                                         "Capscli server hostname / ip")
    def validate_value(self, value):
        # Only accept servers configurated
        return value in self.values('')

    def values(self, incomplete_word):
        return CapscliPlugin.Servers

class CapscliDataFile(bostypes.BiferShellType):
    def __init__(self):
        bostypes.BiferShellType.__init__(self, "Capture data file name")
        
    def validate_value(self, value):
        return value in self.values('')
        
    def values(self, incomplete_word):
        data_dir = CapscliPlugin.DataDir
        return [file.replace(data_dir, '') for file in glob.glob('%s/*.pcap' % data_dir)]


class TransportProtocol(bostypes.BiferShellType):
    def __init__(self):
        bostypes.BiferShellType.__init__(self,
                                         "Transport protocol supported for a capture (tcp, udp, ...)")
        
    def validate_value(self, value):
        return value in self.values('')
        
    def values(self, incomplete_word):
        return ['tcp', 'udp', 'icmp']


boscli.get_cli().add_type('CAPSCLISERVER', CapscliServer())
boscli.get_cli().add_type('CAPSCLIDATAFILE', CapscliDataFile())
boscli.get_cli().add_type('TRANSPROTO', TransportProtocol())


def bcli_capscli(line_words):
    """Capscli itself related commands"""
    # this command only add doc for top level interactive help
    pass

def bcli_capture(line_words):
    """Commands for traffic capture and capture files management"""
    # this command only add doc for top level interactive help    
    pass

def bcli_capscli_show_servers(line_words):
    """Show/list configured servers for capscli"""    
    print "Configured capscli servers:"
    for server in CapscliPlugin.Servers:
        print server
    
def bcli_capture_show(line_words):
    """Show/list captures data files"""
    
    print "Captures data files:"
    data_dir = CapscliPlugin.DataDir    
    for dataFile in CapscliDataFile().values(''):
        size = os.path.getsize(data_dir + os.path.sep + dataFile)
        print "%-20s %20d" % (dataFile, size)


class Capturer():
    """Helper class to perform simple network traffic captures"""
    
    def __init__(self, net_address, port = None, transport = None):
        self.net_address = net_address
        self.port = port
        self.transport = transport

    def capture_file_name(self):
        return "capt-%s.pcap" % datetime.datetime.now().strftime("%Y%m%d-%H%M%S")

    def capture_file_path(self):
        data_dir = CapscliPlugin.DataDir    
        return os.path.abspath(data_dir + os.path.sep + self.capture_file_name())

    def capture(self):
        str_protocol_options = ''
        if self.transport != None:
            str_protocol_options = ' and ' + self.transport
        if self.port != None:
            if str_protocol_options.find('and') == -1:
                str_protocol_options += ' and '
            str_protocol_options += ' port ' + self.port
        
        tcpdump_cmd = "tcpdump -v -i any -w %s net %s %s" % (self.capture_file_path(),
                                                             self.net_address,
                                                             str_protocol_options)
        boscliutils.InteractiveCommand(tcpdump_cmd)
        

def bcli_capture_traffic_IP(line_words):
    """Capture traffic with IP as a src or dst"""
    ip = line_words[2]
    capturer = Capturer(ip)
    print "Use Ctr-C to stop the capture"
    capturer.capture()

def bcli_capture_traffic_IP_TRANSPROTO_INT(line_words):
    """Capture traffic for a host and protocol  (transport proto and port)"""
    ip = line_words[2]
    transport = line_words[3]
    port = line_words[4]    
    capturer = Capturer(ip, port, transport)
    print "Use Ctr-C to stop the capture"
    capturer.capture()

def bcli_capture_traffic_CIDR(line_words):
    """Capture traffic for a subnet"""    
    cidr = line_words[2]
    capturer = Capturer(cidr)
    print "Use Ctr-C to stop the capture"
    capturer.capture()

def bcli_capture_traffic_CIDR_TRANSPROTO_INT(line_words):
    """Capture traffic for a subnet and protocol (transport proto and port)"""        
    cidr = line_words[2]
    transport = line_words[3]
    port = line_words[4]    
    capturer = Capturer(cidr, port, transport)
    print "Use Ctr-C to stop the capture"
    capturer.capture()


def bcli_capscli_conf_reload(line_words):
    """Read/Parse capscli conf"""
    print "Loading conf"
    CapscliPlugin()
    print "Conf loaded..."

